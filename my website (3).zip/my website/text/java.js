    // --- JavaScript for Logic ---

        // 1. Initial State
        let cartItems = []; 
        let cartCountElement = document.getElementById('cartCount');
        const productContainer = document.getElementById('productContainer');

        // Sample Product Data
        const products = [
            { id: 1, name: "Super Widget", price: 19.99 },
            { id: 2, name: "Turbo Gizmo", price: 45.50 },
            { id: 3, name: "Mega Thingy", price: 9.95 },
        ];

        // 2. Core Functions

        // Function to update the number on the cart icon
        function updateCartCounter() {
            // Calculate the total number of items in the cart (sum of quantities)
            const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
            cartCountElement.textContent = totalItems;
        }

// Function to handle the 'Add to Cart' click
        function addToCart(productId) {
            const product = products.find(p => p.id === productId);

            if (!product) return; // Should not happen with good data

            // Check if the item is already in the cart
            const existingItem = cartItems.find(item => item.id === productId);

            if (existingItem) {
                // If it exists, just increase the quantity
                existingItem.quantity += 1;
            } else {
                // If it's new, add it to the cart with quantity 1
                cartItems.push({ 
                    id: product.id, 
                    name: product.name, 
                    price: product.price, 
                    quantity: 1 
                });
            }

            // Update the display
            updateCartCounter();
            console.log("Current Cart:", cartItems); // For debugging
        }

// 3. Product Rendering (Dynamic HTML Generation)

        function renderProducts() {
            products.forEach(product => {
                const card = document.createElement('div');
                card.className = 'product-card';

                card.innerHTML = `
                    <h3>${product.name}</h3>
                    <p>$${product.price.toFixed(2)}</p>
                    <button class="add-to-cart-btn" data-product-id="${product.id}">
                        Add to Cart
                    </button>
                `;
                productContainer.appendChild(card);
            });
        }
 // 4. Event Listener Setup

        // Wait until all HTML is loaded before adding listeners
        document.addEventListener('DOMContentLoaded', () => {
            renderProducts(); // Generate product cards

            // Use event delegation on the product container for all buttons
            productContainer.addEventListener('click', (event) => {
                if (event.target.classList.contains('add-to-cart-btn')) {
                    // Get the product ID from the button's data attribute
                    const productId = parseInt(event.target.dataset.productId);
                    addToCart(productId);
                }
            });
        });
